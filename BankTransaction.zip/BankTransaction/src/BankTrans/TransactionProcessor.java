package BankTrans;

import java.sql.*;

public class TransactionProcessor {

    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        String url = "jdbc:mysql://localhost:3306/Bank";
        String username = "root";
        String password = "MySql@13";

        try (Connection connection = DriverManager.getConnection(url, username, password)) {

            // Create a statement object
            Statement statement = connection.createStatement();

            // Retrieve transactions from the transaction table
            ResultSet resultSet = statement.executeQuery("SELECT * FROM BankTrans");

            while (resultSet.next()) {
                String TransID = resultSet.getString("TransId");
                int AcctNo = resultSet.getInt("AcctNo");
                double OldBal = resultSet.getDouble("OldBal");
                String TransType = resultSet.getString("TransType");
                double TransAmt = resultSet.getInt("TransAmt");

                double NewBal = (TransType.equals("W")) ? (OldBal - TransAmt) : (OldBal + TransAmt);

                if (NewBal > 0) {
                    // Update in the valid table using PreparedStatement
                    try (PreparedStatement preparedStatement = connection.prepareStatement(
                            "INSERT INTO ValidTrans (TransId, TransType, TransAmt, Validity) VALUES (?, ?, ?, 'Valid')")) {
                        preparedStatement.setString(1, TransID);
                        preparedStatement.setString(2, TransType);
                        preparedStatement.setDouble(3, TransAmt);
                        preparedStatement.executeUpdate();
                        
                        System.out.println("Data Inserted into ValidTrans Table");
                        System.out.println("TransId-"+TransID+" TransType-"+TransType+" TransAmt-"+TransAmt+" Validity-Valid");
                    }
                } else {
                    // Update in the invalid table using PreparedStatement
                    try (PreparedStatement preparedStatement = connection.prepareStatement(
                            "INSERT INTO InvalidTrans (TransId, TransType, TransAmt, Validity) VALUES (?, ?, ?, 'Invalid')")) {
                        preparedStatement.setString(1, TransID);
                        preparedStatement.setString(2, TransType);
                        preparedStatement.setDouble(3, TransAmt);
                        preparedStatement.executeUpdate();
                        
                        System.out.println("Data Inserted into InvalidTrans Table");
                        System.out.println("TransId-"+TransID+" TransType-"+TransType+" TransAmt-"+TransAmt+" Validity-Invalid");
                    }
                }
            }

            // Close the resources
            resultSet.close();
            statement.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
